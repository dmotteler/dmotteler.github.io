#! env python
'''
    $Id:$
    $Log:$

    process groupanizer program files to create eventlist xml

'''

import os, sys
import zipfile
from tprogclass import TunersProgram
from datetime import datetime
from xml.etree import ElementTree as ET

libsongs = []
sid = {}
songbysid = {}
songbygdid = {}
songbygdid['11UAeZ_daHsV9o3xbnFdWhqwWDsAW0EaB'] = "Hooked On a Feeling"
songbygdid['13HKMvOdPHLs5KucEMBp9ZtbO6Z4p80ML'] = "Hooked On a Feeling"
songbygdid['1aBW5TB252TnbRQ2k9PFRYH4g68VC5T5O'] = "Hooked On a Feeling"
songbygdid['1duAJGNwzNhISspBiBd9pZMNjYQ4N9y_G'] = "Hooked On a Feeling"
songbygdid['1mVE9mHlOHaLiyDIBfoxoAuCHu_2J17RN'] = "Hooked On a Feeling"
aliasfor = {}
songsincat = {}

def loadlib(lib_xml):
    global aliasfor, libsongs, sid, songbygdid, songbysid, songsincat
    with open(lib_xml, "r") as lib:
        xml = lib.read()
        tree = ET.XML(xml)
        for el in tree:
            song = el.attrib['name']
            songid = el.attrib['id']
            sid[song] = songid
            songbysid[songid] = song
            libsongs.append(song)
            for a in el.findall('alias'):
                if a.text not in aliasfor:
                    aliasfor[a.text] = song
            for c in el.findall('category'):
                if c.text not in songsincat:
                    songsincat[c.text] = set()
                songsincat[c.text].add(song)
            for t in el.findall('tracks'):
                for v in t.findall('voice'):
                    gdid = v.attrib['gdid']
                    songbygdid[gdid] = song

def stripsong(song):
    n1 = song.find("(")
    n2 = song.find("[")
    if n1 > 0:
        if n2 > 0:
            song = song[:min(n1, n2)]
        else:
            song = song[:n1]
    else:
        if n2 > 0:
            song = song[:n2]

    for v in voices:
        n1 = song.lower().find(v)
        if n1 > 0:
            song = song[:n1]

    return song.strip()

def eventxml(xfile, evlist):
    brief = True
    eventlist = "Tuners Event List"
    root = ET.Element("eventlist", attrib={'name': eventlist})

    for dtndx in sorted(evlist):
        ev = evlist[dtndx]

        venue = ev['where']
        evdate = ev['when']
        eventatts = {"where": venue, "when": evdate, "dtndx": dtndx}

        if brief:
            eventatts['songlist'] = " ".join(ev['songlist'])
        else:
            for sid in ev['songlist']:
                songname = songbysid[sid]
                songatts = {"name": songname, "sid": sid}
                songel = ET.SubElement(eventel, "song", attrib=songatts)

        eventel = ET.SubElement(root, "event", attrib=eventatts)

    sl = ET.tostringlist(root, encoding="unicode")
    lines = []
    lines.append("""<?xml version="1.0" encoding="utf-8"?>\n""")
    lines.append("""<?xml-stylesheet type="text/xsl" href="eventlist.xsl"?>\n""")

    leveltags = []

    t = sl.pop(0).rstrip()
    line = [t]
    lastwastag = t.startswith("<")
    assert lastwastag, "first line in writexml not <tag, but {}".format(t)

    # push <tag onto leveltags
    leveltags.append(t)

    putoutline = False
    while len(sl) > 0:
        t = sl.pop(0).rstrip()

        if putoutline:
            nind = len(leveltags)
            # if this line will dedent, adjust now, pop later.
            if t.startswith("</"):
                nind -= 1
            # start a new line, indented by tag level
            line = ["  " * nind, t]
        else:
            line.append(t)

        if t == ">":
            if lastwastag:
                # this just closes the previous <tag line - next will be tag text
                putoutline = False
                poptag = False
            else:
                # this closes an element with children. put line out, but don't pop tag
                putoutline = True
                poptag = False
        elif t == " />":
            # end of closed element. put out line, pop tag
            putoutline = True
            poptag = True
        elif t.startswith("</"):
            if t.endswith(">"):
                # this is </tag> - closes complex tag. put line out, pop tag.
                putoutline = True
                poptag = True
            else:
                raise UserWarning("looks like </tag with no > - didn't expect it! {}".format(t))
        elif t.startswith("<"):
            # this is <tag with no > - push tag, don't put out line
            leveltags.append(t)
            putoutline = False
            poptag = False
        else:
            # no < or > - don't put out line, or pop tag
            putoutline = False
            poptag = False

        if poptag:
            leveltags.pop()

        if putoutline:
            line.append("\n")
            lines.append("".join(line))

        lastwastag = t.startswith("<")

    with open(xfile, "w", encoding="utf-8") as xo:
        for l in lines:
            xo.write(l)

    print("Created {}".format(xfile))

lfile = "C:/cygwin64/home/Del/trygitpages/dmotteler.github.io/musiclib/musiclib.xml"
loadlib(lfile)

zfn = "../php_ws/lastperf/progcache.zip"
zdir = "progcache/"
lzdir = len(zdir)

voices = ['bass', 'bari', 'lead', 'tenor', 'mix']
evlist = {}

zf = zipfile.ZipFile(zfn, "r")
# for each archive element...
for info in zf.infolist():
    # just skip the folder entries
    if info.is_dir():
        continue
    fn = info.filename

    # read the element and parse it 
    if not fn.endswith(".html"):
        continue
    if fn[lzdir:].startswith("perf"):
        dts = fn[4:-5]
    elif fn[lzdir:].startswith("reh"):
        dts = fn[3:-5]
    else:
        # print("didn't like {}".format(fn))
        # there are lots of elements in subfolders by year
        # (progcache/2018/...)
        continue

    tp = TunersProgram(zf, fn)
    if len(tp.rows) < 1:
        continue

    # title is <venue> - <date> | Two Town Tuners
    if tp.title.endswith(" | Two Town Tuners"):
        vendts = tp.title[:-18].split(" - ")
        if len(vendts) != 2:
            print(" >>> what's this? {}".format(vendts))
            continue
        else:
            ven, dts = vendts
            dt = datetime.strptime(dts, "%Y-%b-%d")
    else:
        print(" >>> {} doesn't end with Two Town Tuners?!".format(tp.title))
        continue

    # if tp.progstart < datetime(2020, 6, 1):
        # continue

    songlist = []
    for row in tp.rows:
        song = row[1].replace("&#039;", "'")

        if song in ["", "-- qtet choice --", "Break"]:
            continue

        song = stripsong(song)

        if song not in sid:
            if "choice" in song.lower() or "break" in song.lower():
                continue
            print("{} not in sid. {}".format(song, fn))
            continue

        if song in aliasfor:
            song = aliasfor[song]

        if not song in libsongs:
            print("{} not in lib?".format(song))

        # add the song id to the song list, if it's not there
        songid = sid[song]
        if not songid in songlist:
            songlist.append(songid)

    ev = {'when': tp.progstart.strftime("%B %d, %Y %H%M%p"), 'where': ven, 'songlist': songlist}

    evndx = tp.progstart.strftime("%Y%m%d%H%M")
    if evndx in evlist:
        print("duplicate evndx {} from {}".format(evndx, path))
        pass
    else:
        evlist[evndx] = ev

eventxml("gaevents.xml", evlist)
